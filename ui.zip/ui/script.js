// Global Application State
let loadedPdf = null; // Stores metadata about the loaded PDF
let currentTheme = 'dark';
let activeTab = 'range'; // 'range' or 'size'
let rangeType = 'custom'; // 'custom' or 'every'

// Helper to clean quotes and trim spaces from paths (common when copying paths on Windows)
function cleanPath(path) {
    if (!path) return '';
    return path.trim().replace(/^['"]|['"]$/g, '');
}

// DOM Elements
const body = document.body;
const themeToggle = document.getElementById('theme-toggle');
const dropZone = document.getElementById('drop-zone');
const pdfPathInput = document.getElementById('pdf-path');
const destPathInput = document.getElementById('dest-path');
const btnBrowseFile = document.getElementById('btn-browse-file');
const btnBrowseFolder = document.getElementById('btn-browse-folder');
const pdfMetaCard = document.getElementById('pdf-meta-card');
const metaFilename = document.getElementById('meta-filename');
const metaPages = document.getElementById('meta-pages');
const metaSize = document.getElementById('meta-size');
const btnClearFile = document.getElementById('btn-clear-file');

const tabRange = document.getElementById('tab-range');
const tabSize = document.getElementById('tab-size');
const rangePanel = document.getElementById('range-panel');
const sizePanel = document.getElementById('size-panel');

const customRangeInputs = document.getElementById('custom-range-inputs');
const everyPageInputs = document.getElementById('every-page-inputs');
const customRangeVal = document.getElementById('custom-range-val');
const rangeValidation = document.getElementById('range-validation');
const everyPageVal = document.getElementById('every-page-val');
const everyPageLbl = document.getElementById('every-page-lbl');
const targetSizeVal = document.getElementById('target-size-val');
const targetSizeLbl = document.getElementById('target-size-lbl');

const btnSplit = document.getElementById('btn-split');
const progressContainer = document.getElementById('progress-container');
const progressStatus = document.getElementById('progress-status');
const progressPercent = document.getElementById('progress-percent');
const progressBarFill = document.getElementById('progress-bar-fill');
const logConsole = document.getElementById('log-console');
const btnClearLogs = document.getElementById('btn-clear-logs');

const successCard = document.getElementById('success-card');
const btnOpenFolder = document.getElementById('btn-open-folder');
const btnDismissSuccess = document.getElementById('btn-dismiss-success');

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    setupEventListeners();
    addLogLine('System initialized. Awaiting PDF selection...', 'system');
});

// Theme Management
function initTheme() {
    let savedTheme = 'dark';
    try {
        savedTheme = localStorage.getItem('theme') || 'dark';
    } catch (e) {
        console.warn('localStorage is not accessible, using default dark theme:', e);
    }
    setTheme(savedTheme);
}

function setTheme(theme) {
    currentTheme = theme;
    if (theme === 'light') {
        body.classList.remove('dark-theme');
        body.classList.add('light-theme');
    } else {
        body.classList.remove('light-theme');
        body.classList.add('dark-theme');
    }
    try {
        localStorage.setItem('theme', theme);
    } catch (e) {
        console.warn('localStorage write blocked:', e);
    }
}

// Event Listeners Setup
function setupEventListeners() {
    // Theme Toggle
    themeToggle.addEventListener('click', () => {
        setTheme(currentTheme === 'dark' ? 'light' : 'dark');
    });

    // File Browser Dialog
    btnBrowseFile.addEventListener('click', selectFileViaPython);
    dropZone.addEventListener('click', (e) => {
        // Prevent click if we clicked inside path inputs or button
        if (!e.target.closest('.path-input-group') && !e.target.closest('.pdf-meta-card')) {
            selectFileViaPython();
        }
    });

    // Manual Path Changes
    pdfPathInput.addEventListener('change', () => {
        const path = cleanPath(pdfPathInput.value);
        pdfPathInput.value = path;
        if (path) loadPdfMetadata(path);
    });

    // Clear File
    btnClearFile.addEventListener('click', clearLoadedPdf);

    // Folder Browser Dialog
    btnBrowseFolder.addEventListener('click', selectFolderViaPython);

    // Drag & Drop Listeners
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            
            // In pywebview / Electron context, file.path exposes the local filesystem path if privileged.
            // Otherwise, it falls back to the name.
            const localPath = file.path || file.name;
            
            if (localPath.toLowerCase().endsWith('.pdf')) {
                // Check if it's a full path (Windows drive letters like C:\ or network path \\)
                const isAbsolutePath = /^[a-zA-Z]:[\\/]/.test(localPath) || localPath.startsWith('\\\\');
                
                if (isAbsolutePath) {
                    pdfPathInput.value = localPath;
                    loadPdfMetadata(localPath);
                } else {
                    addLogLine("Security restrictions prevent reading the full path via Drag & Drop. Please click 'Browse' or enter the path manually.", "error");
                }
            } else {
                addLogLine('Error: Only PDF files can be processed.', 'error');
            }
        }
    });

    // Tab Navigation
    tabRange.addEventListener('click', () => switchTab('range'));
    tabSize.addEventListener('click', () => switchTab('size'));

    // Range Sub-toggle (Custom vs Every N)
    const rangeRadioGroup = document.getElementsByName('range-type');
    rangeRadioGroup.forEach(radio => {
        radio.addEventListener('change', (e) => {
            rangeType = e.target.value;
            if (rangeType === 'custom') {
                customRangeInputs.classList.remove('hidden');
                everyPageInputs.classList.add('hidden');
                validateCustomRange();
            } else {
                customRangeInputs.classList.add('hidden');
                everyPageInputs.classList.remove('hidden');
                validateInputs(); // Re-evaluate button activation
            }
        });
    });

    // Live Range Input Validation
    customRangeVal.addEventListener('input', validateCustomRange);

    // Slider Listeners
    everyPageVal.addEventListener('input', () => {
        everyPageLbl.textContent = `${everyPageVal.value} page${everyPageVal.value > 1 ? 's' : ''}`;
    });

    targetSizeVal.addEventListener('input', () => {
        targetSizeLbl.textContent = `${parseFloat(targetSizeVal.value).toFixed(1)} MB`;
    });

    // Action button
    btnSplit.addEventListener('click', startSplitProcess);

    // Clear logs
    btnClearLogs.addEventListener('click', () => {
        logConsole.innerHTML = '';
        addLogLine('Logs cleared.', 'system');
    });

    // Success Actions
    btnOpenFolder.addEventListener('click', openOutputFolder);
    btnDismissSuccess.addEventListener('click', () => {
        successCard.classList.add('hidden');
    });

    // Listen for pywebview ready event
    window.addEventListener('pywebviewready', () => {
        addLogLine('Desktop engine connection established.', 'success');
    });
}

// ----------------------------------------------------
// Python API Call Wrappers
// ----------------------------------------------------

function selectFileViaPython() {
    if (window.pywebview && window.pywebview.api) {
        addLogLine('Opening file selection dialog...', 'system');
        window.pywebview.api.select_file().then(handlePdfLoadResult);
    } else {
        addLogLine('Error: Desktop integration not loaded.', 'error');
    }
}

function selectFolderViaPython() {
    if (window.pywebview && window.pywebview.api) {
        addLogLine('Opening folder selection dialog...', 'system');
        window.pywebview.api.select_folder().then(result => {
            if (result.status === 'success') {
                destPathInput.value = result.folder_path;
                addLogLine(`Output folder set to: ${result.folder_path}`, 'system');
                validateInputs();
            } else if (result.status === 'cancelled') {
                addLogLine('Folder selection cancelled.', 'system');
            }
        });
    } else {
        addLogLine('Error: Desktop integration not loaded.', 'error');
    }
}

function loadPdfMetadata(path) {
    if (window.pywebview && window.pywebview.api) {
        addLogLine(`Loading file info for: ${path}...`, 'system');
        window.pywebview.api.load_pdf_metadata(path).then(handlePdfLoadResult);
    } else {
        addLogLine('Error: Desktop integration not loaded.', 'error');
    }
}

function handlePdfLoadResult(result) {
    if (result.status === 'success') {
        loadedPdf = result;
        
        // Update paths in inputs
        pdfPathInput.value = result.file_path;
        if (!destPathInput.value) {
            destPathInput.value = result.suggested_output_dir;
        }

        // Show metadata card
        metaFilename.textContent = result.filename;
        metaFilename.title = result.filename;
        metaPages.textContent = `${result.pages} page${result.pages !== 1 ? 's' : ''}`;
        metaSize.textContent = `${result.size_mb} MB`;
        pdfMetaCard.classList.remove('hidden');
        
        // Update ranges configuration slider max page limits
        everyPageVal.max = result.pages;
        if (parseInt(everyPageVal.value) > result.pages) {
            everyPageVal.value = Math.min(3, result.pages);
        }
        everyPageLbl.textContent = `${everyPageVal.value} page${everyPageVal.value > 1 ? 's' : ''}`;

        addLogLine(`Successfully loaded: ${result.filename} (${result.pages} pages, ${result.size_mb} MB)`, 'success');
        
        // Reset custom range input validation
        validateCustomRange();
    } else if (result.status === 'error') {
        addLogLine(`Error: ${result.message}`, 'error');
        clearLoadedPdf();
    } else {
        addLogLine('File selection cancelled.', 'system');
    }
}

function clearLoadedPdf() {
    loadedPdf = null;
    pdfPathInput.value = '';
    pdfMetaCard.classList.add('hidden');
    btnSplit.disabled = true;
    rangeValidation.textContent = '';
    rangeValidation.className = 'validation-message';
    addLogLine('Source PDF unloaded.', 'system');
}

// ----------------------------------------------------
// UI Logic & Validation
// ----------------------------------------------------

function switchTab(tab) {
    activeTab = tab;
    if (tab === 'range') {
        tabRange.classList.add('active');
        tabSize.classList.remove('active');
        rangePanel.classList.add('active');
        sizePanel.classList.remove('active');
    } else {
        tabRange.classList.remove('active');
        tabSize.classList.add('active');
        rangePanel.classList.remove('active');
        sizePanel.classList.add('active');
    }
    validateInputs();
}

function validateCustomRange() {
    if (!loadedPdf) {
        rangeValidation.textContent = '';
        validateInputs();
        return;
    }

    const value = customRangeVal.value.trim();
    if (!value) {
        rangeValidation.textContent = 'Please enter page ranges.';
        rangeValidation.className = 'validation-message error';
        validateInputs();
        return;
    }

    const totalPages = loadedPdf.pages;
    const parts = value.split(',');
    let isValid = true;
    let errorMsg = '';

    for (let i = 0; i < parts.length; i++) {
        const part = parts[i].trim();
        if (!part) continue;

        if (part.includes('-')) {
            const subparts = part.split('-');
            if (subparts.length !== 2) {
                isValid = false;
                errorMsg = `Invalid range format: "${part}"`;
                break;
            }
            const start = parseInt(subparts[0].trim());
            const end = parseInt(subparts[1].trim());

            if (isNaN(start) || isNaN(end)) {
                isValid = false;
                errorMsg = `Range bounds must be numeric: "${part}"`;
                break;
            }
            if (start <= 0 || end <= 0) {
                isValid = false;
                errorMsg = `Page numbers must be 1 or higher: "${part}"`;
                break;
            }
            if (start > totalPages || end > totalPages) {
                isValid = false;
                errorMsg = `Page exceeds total pages (${totalPages}): "${part}"`;
                break;
            }
            if (start > end) {
                isValid = false;
                errorMsg = `Start page cannot exceed end page: "${part}"`;
                break;
            }
        } else {
            const pageNum = parseInt(part);
            if (isNaN(pageNum)) {
                isValid = false;
                errorMsg = `Invalid page number: "${part}"`;
                break;
            }
            if (pageNum <= 0) {
                isValid = false;
                errorMsg = `Page number must be 1 or higher: "${part}"`;
                break;
            }
            if (pageNum > totalPages) {
                isValid = false;
                errorMsg = `Page exceeds total pages (${totalPages}): "${part}"`;
                break;
            }
        }
    }

    if (isValid) {
        rangeValidation.textContent = '✓ Page ranges are valid';
        rangeValidation.className = 'validation-message success';
    } else {
        rangeValidation.textContent = `✗ ${errorMsg}`;
        rangeValidation.className = 'validation-message error';
    }

    validateInputs();
}

function validateInputs() {
    const isFileLoaded = loadedPdf !== null;
    const isDestPathProvided = destPathInput.value.trim().length > 0;
    
    let isConfigValid = false;
    if (activeTab === 'range') {
        if (rangeType === 'custom') {
            isConfigValid = rangeValidation.className.includes('success');
        } else {
            isConfigValid = true; // Slider value is always valid
        }
    } else {
        isConfigValid = parseFloat(targetSizeVal.value) > 0;
    }

    btnSplit.disabled = !(isFileLoaded && isDestPathProvided && isConfigValid);
}

// Watch destination path input manually as well
destPathInput.addEventListener('input', validateInputs);

// ----------------------------------------------------
// PDF Splitting Actions
// ----------------------------------------------------

function startSplitProcess() {
    if (!loadedPdf) return;

    const filePath = cleanPath(pdfPathInput.value);
    const destPath = cleanPath(destPathInput.value);
    pdfPathInput.value = filePath;
    destPathInput.value = destPath;
    
    let configVal = '';
    
    if (activeTab === 'range') {
        if (rangeType === 'custom') {
            configVal = customRangeVal.value.trim();
        } else {
            configVal = `every:${everyPageVal.value}`;
        }
    } else {
        configVal = parseFloat(targetSizeVal.value);
    }

    // Toggle UI inputs to disabled state during process
    toggleInputs(true);
    
    // Show progress bar container
    progressContainer.classList.remove('hidden');
    progressPercent.textContent = '0%';
    progressBarFill.style.width = '0%';
    progressStatus.textContent = 'Starting processing...';
    
    addLogLine('--------------------------------------------', 'system');
    addLogLine('Initiating PDF Splitting operation...', 'system');
    addLogLine(`Source file: ${filePath}`, 'system');
    addLogLine(`Output directory: ${destPath}`, 'system');
    addLogLine(`Split mode: ${activeTab} (Config: ${configVal})`, 'system');

    // Call Python api
    if (window.pywebview && window.pywebview.api) {
        window.pywebview.api.split_pdf(filePath, destPath, activeTab, configVal)
            .then(result => {
                if (result.status === 'error') {
                    addLogLine(`Error starting process: ${result.message}`, 'error');
                    toggleInputs(false);
                    progressContainer.classList.add('hidden');
                }
            })
            .catch(err => {
                addLogLine(`Execution Error: ${err}`, 'error');
                toggleInputs(false);
                progressContainer.classList.add('hidden');
            });
    } else {
        addLogLine('Error: Desktop API connection lost.', 'error');
        toggleInputs(false);
    }
}

// This function is called from the Python API thread
window.updateProgress = function(progressPct, message, done, error) {
    // Perform updates in DOM
    progressPercent.textContent = `${progressPct}%`;
    progressBarFill.style.width = `${progressPct}%`;
    progressStatus.textContent = message;

    if (error) {
        addLogLine(`[ERROR] ${message}`, 'error');
        addLogLine(`Process terminated with errors: ${error}`, 'error');
        toggleInputs(false);
        return;
    }

    if (done) {
        addLogLine(`[SUCCESS] ${message}`, 'success');
        toggleInputs(false);
        // Show success screen
        successCard.classList.remove('hidden');
    } else {
        addLogLine(message, 'progress');
    }
};

function openOutputFolder() {
    const destPath = cleanPath(destPathInput.value);
    destPathInput.value = destPath;
    if (destPath && window.pywebview && window.pywebview.api) {
        window.pywebview.api.open_folder(destPath).then(result => {
            if (result.status === 'error') {
                addLogLine(`Could not open output folder: ${result.message}`, 'error');
            }
        });
    }
}

function toggleInputs(disabled) {
    btnBrowseFile.disabled = disabled;
    btnBrowseFolder.disabled = disabled;
    pdfPathInput.disabled = disabled;
    destPathInput.disabled = disabled;
    customRangeVal.disabled = disabled;
    everyPageVal.disabled = disabled;
    targetSizeVal.disabled = disabled;
    btnSplit.disabled = disabled || !loadedPdf;
    btnClearFile.disabled = disabled;
    
    const radioGroup = document.getElementsByName('range-type');
    radioGroup.forEach(radio => radio.disabled = disabled);

    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => btn.disabled = disabled);
    
    if (disabled) {
        dropZone.style.pointerEvents = 'none';
        dropZone.style.opacity = '0.5';
    } else {
        dropZone.style.pointerEvents = 'auto';
        dropZone.style.opacity = '1';
    }
}

// Logger helper
function addLogLine(text, type = 'progress') {
    const line = document.createElement('div');
    line.className = `log-line ${type}-msg`;
    
    // Add simple timestamp
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
    line.textContent = `[${timeStr}] ${text}`;
    
    logConsole.appendChild(line);
    
    // Scroll console to bottom
    logConsole.scrollTop = logConsole.scrollHeight;
}
